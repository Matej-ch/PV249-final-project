require 'test_helper'

class DocumentTest < ActiveSupport::TestCase
end
