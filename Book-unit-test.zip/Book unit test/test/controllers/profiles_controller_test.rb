require 'test_helper'

class ProfilesControllerTest < ActionController::TestCase
end
