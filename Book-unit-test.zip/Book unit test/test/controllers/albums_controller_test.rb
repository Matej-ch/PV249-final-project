require 'test_helper'

class AlbumsControllerTest < ActionController::TestCase
end
