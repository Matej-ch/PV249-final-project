require 'test_helper'

class MessagesControllerTest < ActionController::TestCase
end
