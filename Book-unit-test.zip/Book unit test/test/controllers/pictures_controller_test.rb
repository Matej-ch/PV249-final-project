require 'test_helper'

class PicturesControllerTest < ActionController::TestCase
end
