require 'test_helper'

class StatusesControllerTest < ActionController::TestCase
end
