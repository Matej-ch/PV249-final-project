require 'test_helper'

class UserFriendshipsControllerTest < ActionController::TestCase
end
