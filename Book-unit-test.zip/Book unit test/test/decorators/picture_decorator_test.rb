require 'test_helper'

class PictureDecoratorTest < Draper::TestCase
end
