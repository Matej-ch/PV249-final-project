require 'test_helper'

class AlbumDecoratorTest < Draper::TestCase
end
