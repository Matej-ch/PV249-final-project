require 'test_helper'

class ActivityDecoratorTest < Draper::TestCase
end
