require 'test_helper'

class MessageDecoratorTest < Draper::TestCase
end
