require 'test_helper'

class ConversationDecoratorTest < Draper::TestCase
end
