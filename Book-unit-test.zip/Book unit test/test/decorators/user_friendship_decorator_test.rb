require 'test_helper'

class UserFriendshipDecoratorTest < Draper::TestCase
end
